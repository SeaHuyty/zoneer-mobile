// Core Utils - Constants
// This file contains app-wide constant values
// Define API endpoints, configuration values, theme constants, etc.
// Centralized location for all constant values used throughout the app
