// Shared Widgets - Custom Button
// This file contains a reusable custom button widget
// Provides consistent button styling and behavior across the app
// Used in multiple features for primary, secondary, and text buttons
