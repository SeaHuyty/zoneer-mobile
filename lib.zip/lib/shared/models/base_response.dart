// Shared Models - Base Response
// This file contains the base response model for API responses
// Provides common structure for all API responses (success, error, data)
// Used as parent class or wrapper for feature-specific responses
