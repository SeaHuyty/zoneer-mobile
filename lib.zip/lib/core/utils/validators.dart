// Core Utils - Validators
// This file contains validation helper functions
// Provides email, password, phone number, and other input validations
// Reusable across all forms in the application

