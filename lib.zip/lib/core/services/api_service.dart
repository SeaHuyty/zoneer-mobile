// Core Services - API Service
// This file contains the API service for handling HTTP requests
// Provides methods for REST API calls, authentication headers, and error handling
// Used across all features for network communication
